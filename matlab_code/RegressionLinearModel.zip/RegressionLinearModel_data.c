/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * RegressionLinearModel_data.c
 *
 * Code generation for function 'RegressionLinearModel_data'
 *
 */

/* Include files */
#include "RegressionLinearModel_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
RegressionLinear model;

bool isInitialized_RegressionLinearModel = false;

/* End of code generation (RegressionLinearModel_data.c) */
