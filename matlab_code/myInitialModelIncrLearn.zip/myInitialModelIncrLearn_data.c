/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * myInitialModelIncrLearn_data.c
 *
 * Code generation for function 'myInitialModelIncrLearn_data'
 *
 */

/* Include files */
#include "myInitialModelIncrLearn_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
unsigned int state[625];

bool isInitialized_myInitialModelIncrLearn = false;

/* End of code generation (myInitialModelIncrLearn_data.c) */
