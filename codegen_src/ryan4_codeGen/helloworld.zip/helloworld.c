/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * helloworld.c
 *
 * Code generation for function 'helloworld'
 *
 */

/* Include files */
#include "helloworld.h"
#include <stdio.h>

/* Function Definitions */
void helloworld(void)
{
  printf("hello world!\n");
  fflush(stdout);
}

/* End of code generation (helloworld.c) */
