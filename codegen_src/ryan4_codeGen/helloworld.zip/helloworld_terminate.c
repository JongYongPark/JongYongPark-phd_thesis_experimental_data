/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * helloworld_terminate.c
 *
 * Code generation for function 'helloworld_terminate'
 *
 */

/* Include files */
#include "helloworld_terminate.h"

/* Function Definitions */
void helloworld_terminate(void)
{
}

/* End of code generation (helloworld_terminate.c) */
