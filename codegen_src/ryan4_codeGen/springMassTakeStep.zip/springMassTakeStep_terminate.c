/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * springMassTakeStep_terminate.c
 *
 * Code generation for function 'springMassTakeStep_terminate'
 *
 */

/* Include files */
#include "springMassTakeStep_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void springMassTakeStep_terminate(void)
{
}

/* End of code generation (springMassTakeStep_terminate.c) */
