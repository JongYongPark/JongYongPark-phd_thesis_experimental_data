/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * springMassTakeStep_initialize.c
 *
 * Code generation for function 'springMassTakeStep_initialize'
 *
 */

/* Include files */
#include "springMassTakeStep_initialize.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void springMassTakeStep_initialize(void)
{
}

/* End of code generation (springMassTakeStep_initialize.c) */
