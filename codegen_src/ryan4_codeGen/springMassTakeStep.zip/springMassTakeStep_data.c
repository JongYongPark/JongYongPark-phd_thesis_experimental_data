/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * springMassTakeStep_data.c
 *
 * Code generation for function 'springMassTakeStep_data'
 *
 */

/* Include files */
#include "springMassTakeStep_data.h"
#include "rt_nonfinite.h"

/* End of code generation (springMassTakeStep_data.c) */
