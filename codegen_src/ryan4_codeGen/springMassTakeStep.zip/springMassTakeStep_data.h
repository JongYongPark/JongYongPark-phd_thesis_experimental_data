/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * springMassTakeStep_data.h
 *
 * Code generation for function 'springMassTakeStep_data'
 *
 */

#ifndef SPRINGMASSTAKESTEP_DATA_H
#define SPRINGMASSTAKESTEP_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/* End of code generation (springMassTakeStep_data.h) */
